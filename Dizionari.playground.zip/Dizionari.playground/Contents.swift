import UIKit

var str = "Hello, playground"

// Dizionario = [chiave: valore, chiave, valore], tipo Json. Decidiamo noi in che posizione mettere un valore

// Dichiarazione implicita
var dizionarioImplicito = [1 : 4, 2 : 8, 3 : 12, 4 : 16] // Chiave: Valore
dizionarioImplicito[2] // Prendo variabili

// Dichiarazione esplicita
var dizionarioEsplicito : [String : String] = ["Saluto" : "Ciao", "Richiesta" : "Bicchiere d'acqua"] // Chiave di tipo String (prima dichiarazione) e valore di tipo String (seconda dichiarazione)
dizionarioEsplicito["Saluto"]

// Inizializzazione vuota
var dizionarioVuoto = [Int : String]()

// Eliminare
dizionarioEsplicito["Richiesta"] = nil

// Eliminare tutto
dizionarioEsplicito.removeAll()

// Aggiungere / Modificare
dizionarioEsplicito.updateValue("The Grinch", forKey: "Film preferito")
dizionarioEsplicito.updateValue("Come un Gatto in Tangenziale", forKey: "Film preferito")
dizionarioEsplicito.updateValue("iPhone XS Max", forKey: "Smartphone preferito")

// Stampa
for x in dizionarioEsplicito{
    print("\(x.0) -- \(x.1)\n");
}
