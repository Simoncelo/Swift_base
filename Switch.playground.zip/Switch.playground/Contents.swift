import UIKit;

var str = "Hello, playground";


var votoMassimo = 30;
var voto = 31;

var log : [Int] = [votoMassimo / 10];
switch voto {
case 0...votoMassimo / 2:
    print("Voto insufficente");
case (votoMassimo / 10 * 6)...(votoMassimo / 10 * 7):
    print("Voto sufficente");
case (votoMassimo / 10 * 8)...(votoMassimo / 10 * 9):
    print("Voto molto buono");
case (votoMassimo):
    print("Voto eccellente");
default:
    print("Il voto non è compreso tra 0 e \(votoMassimo)");
}
