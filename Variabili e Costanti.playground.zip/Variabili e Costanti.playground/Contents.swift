import UIKit

var str = "Hello, playground"

// Questo è un commento

// Creo una costante che conterrà gli anni di una persona in formato numerico intero
let anni = 13

// Creo una costante che conterrà il nome di una persona in formato testo
let nome = "Simone"

/*
    Commento su più righe
    1) Commento
    2) Commento
    3) Ecc...
*/

// Creo costante
let inva = 22

// Creo variabile
var punteggio = 50

// Dichairazione tipo di dato (esplicita)
let spesaGennaio: Int = 50
let spesaFebbraio: Double = 40.24

// Dichiarazione implicita
let stringa = "Ciao!"
let numeroIntero = 2

// In una costante esplicita si può definire il valore di una variabile in un calcolo
/*
    String()
    Double()
    Int()
*/
let spesaTotale: Double = Double(spesaGennaio) + spesaFebbraio

let titolo = "Il trono di Spade "
let stagione = 7
let prossimaStagione = stagione + 1

let messaggio = titolo + String(stagione)
