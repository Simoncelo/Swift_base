import UIKit

var str = "Hello, playground"

/*
 Int        Tutti i numeri interi positivi e negativi. Esempio: -1, -2, +3321, 0
 Float      Rappresenta l'insieme dei numeri reali, (gli Int + i numeri con la virgola).
            Esempio: -4.2, 2.004, 55, 31, 0.1
 Double     Simile al Float ma con una precisione dopo la virgola maggiore. Di default quando inserisci un numero con la virgola Swift lo interpreta come Double e non come Float
 Character  Rappresenta i caratteri, si può assegnare solo un carattere ad una var o let, altrimenti diventa una stringa. Quando lo si assegna ad una var deve essere racchiuso tra le virgolette " ". Esempio: "A" "b" "Z" "8"
 String     Più caratteri formano una stringa. Esempio: "Il risultato è", "Il mio nome è Simone"
 Bool       Rappresenta la confizione vero (true) o falso (false)
*/

let a: Int = 2
let aa = Float(a)
let b: Float = 2.123456789
let bb = Int(b)
let c: Double = 2.123456789
let d: Character = "c"
let e: String = "Fracassetti"
let fa: Bool = true
let fb: Bool = false


// Operazioni aritmetiche
/*

 +   Addizione
 -   Sottrazione
 *   Motiplicazione
 /   Divisione
 
*/

let num01 = 5
let num02 = 3

let addizione = num01 + num02 // Addizione tra due numeri
let sottrazione = num01 + num02 // Sottrazione tra due numeri
let moltiplicazione = num01 + num02 // Moltiplicazione tra due numeri
let divisione = num01 + num02 // Divisione tra due numeri

// Espressioni
let risultato = num01 + num02 / 3 // Darà la precedenza alle divisioni e moltiplicazioni, perciò sarebbe: x + (y / 3)
let risultatoEx = (num01 + num02) * 3 // Espressione con parentesi, la precedenza è espressa dalle parentesi

// Escape - Formattazioni
var stringa = "Prima riga\nSeconda riga\n Terza riga" // L'escape "\n" va a capo
stringa = "1,\t2" // L'escape "\t" simula una tabulazione, in questo caso: (1,  2)
stringa = "Ecco il simbolo della backslash: \\" // L'escape "\\" equivale a "\"
stringa = "Ecco le virgolette: \"Ciao!\"" // Per scrivere le virgolette senza "rovinare" il codice basta usare \", stessa cosa negli apostrofi. \'

// Relazioni e condizioni

/*
 
 >      Magggiore di
 <      Maggiore di
 >=     Maggiore o uguale
 <=     Minore o uguale
 ==     Uguale a
 !=     Diverso di
 &&     E
 ||     Oppure
 
 
*/

var numero1 = 1
var numero2 = 2

numero1 > numero2 // numero1 è maggiore di numero2?
numero1 < numero1 // numero1 è minore di numero2?
numero1 >= numero2 // numero1 è maggiore o uguale di numero2?
numero1 <= numero2 // numero1 è minore o uguale di numero2?
numero1 == numero2 // numero1 è uguale a numero2?
numero1 != numero2 // numero1 è diverso da numero2?
