import UIKit

var str = "Hello, playground"

var array : [Int] = [2,4,6,7,3,4,3,42,3489,3498];

// Metodo non consigliato e errato
print("Metodo non consigliato");
print(array[0]);
print(array[1]);
print(array[2]);
print(array[3]);
print(array[4]);
print(array[5]);
print(array[6]);
print(array[8]);
print(array[9]);
print("\n\n#-#-#-#\n\nMetodo consigliato:");
/*
    for <variabile di appoggio> in <intervallo>{
        # Istruzioni
    }
*/
for x in array{
    print(x);
}

var dizionario = ["Simone" : 13, "Antonella" : 49, "Stefano" : 55]
for (nome, eta) in dizionario {
    print("\(nome) ha: \(eta) anni!");
}


// Loop
for x in 1...5 { // _ = nessun nome per la variabile di appoggio, 1...5 = 5 volte - da 1 a 5
    print("Simone \(x)");
}

var indice = 0;
while indice < 100{ // quando (indice < 10) è vero...
    indice += 1; // indice = indice + 1;
    print("Sì \(indice)");
}
