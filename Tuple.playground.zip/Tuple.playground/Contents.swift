import UIKit

var str = "Hello, playground"

// Tuple, contiene due o più valori valori

// Dichiarazione implicita
var codiceErrore = (404, "Pagina no trovata");

// Dichiarazione esplicita
var codiceErrore2 : (Int, String) = (404, "Pagina no trovata");
