import UIKit

var str = "Hello, playground"

// Imposto variabili
var numero1 = 5
var numero2 = 3
// Calcolo
var totale = numero1 + numero2
// Stampa
print("La somma dei due numeri è: \(totale)");
