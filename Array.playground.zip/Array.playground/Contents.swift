import UIKit

var str = "Hello, playground"

// Un array è come un treno, ha dei vagone, i quali contengono dei valori. Deve inoltre essere inizializzata per essere utilizzata
var arrayImplicita = [12,12]
var arrayEsplicita: [Int] = [2] // Variabile NON INIZIALIZZATA

// Aggiungere un valore ad un array
arrayImplicita.append(13) // AGGIUNGIAMO UN VALORE ALL'ARRAY
arrayImplicita.append(13) // AGGIUNGIAMO UN VALORE ALL'ARRAY
arrayImplicita.append(123) // AGGIUNGIAMO UN VALORE ALL'ARRAY
arrayImplicita.append(453) // AGGIUNGIAMO UN VALORE ALL'ARRAY

// Eliminare un valore ad un array
arrayImplicita.remove(at: 0) // RIMUOVIAMO IL VALORE ALLA POSIZIONE 0 (PRIMO ELEMENTO)
arrayImplicita.remove(at: 0) // RIMUOVIAMO IL NUOVO VALORE ALLA POSIZIONE 0 (EX SECONDO ELEMENTO, ATTUALE PRIMO ELEMENTO)

// Eliminare tutto da un array
arrayImplicita.removeAll()

// Modificare un valore da un array
arrayEsplicita[0] = 4 // Modifico il primo elemento, alla posizione 0, sostituendolo con il numero 4.

// Leggere un valore da un array
var posizione: Int = 0
arrayEsplicita[0] // Leggo il valore alla posizione 0

// Inizializzazione array vuota e inizializzata
var arrayVuota = [Int]()
print(arrayVuota);

// Numero di valori in un array
arrayImplicita.count
arrayEsplicita.count
