import UIKit

var str = "Hello, playground"

/*
    if(condizione){
        # code
    }
    else{
        # code
    }
*/



/*
 
 >      Magggiore di
 <      Maggiore di
 >=     Maggiore o uguale
 <=     Minore o uguale
 ==     Uguale a
 !=     Diverso di
 &&     E
 ||     Oppure
 
 
 */

var array : [Int] = [2,4,6];
var numero3 = 3.123;
var dizionario : [String : String] = ["Nome":"Simone","Cognome":"Fracassetti"];

if(Double(array[0]) + numero3 == 5.123){
    print(true);
}

if(array[0] + array[1] == array[2] && dizionario["Nome"] == "Simone"){
    print(true);
}
else{
    print(false);
}

if(2 != 2){
    print(true); // IL COMPILATORE CI DIRÀ ESPLICITAMENTE CHE QUESTO CODICE NON VERERA MAI ESEGUITO
}
else{
    print(false);
}

// Forma non contratta
if(1 == 1){
    print(true);
}
// Forma contratta
1 == 1 ? "Sì" : "No";

array[0] + array[1] == array[2] ? (print(array[2])) : (print(false));
